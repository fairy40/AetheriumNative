#include <jni.h>
#include <string>

extern "C" JNIEXPORT jstring JNICALL
Java_com_aetherium_nexus_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */) {
    std::string hello = "Bem-vindo ao Aetherium Nexus 3D!";
    return env->NewStringUTF(hello.c_str());
}