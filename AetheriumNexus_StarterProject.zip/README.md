# Aetherium Nexus
Projeto 3D realista com Babylon.js Native.